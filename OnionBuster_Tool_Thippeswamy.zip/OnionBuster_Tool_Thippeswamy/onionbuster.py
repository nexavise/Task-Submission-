#!/usr/bin/env python3
"""
OnionBuster
A safe Tor-based directory enumeration tool for .onion services
Author: YourName
License: GNU GPL v3
"""

import argparse
import requests
import time
from colorama import Fore, Style, init

init(autoreset=True)

# Tor proxy
PROXIES = {
    "http": "socks5h://127.0.0.1:9050",
    "https": "socks5h://127.0.0.1:9050"
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Tor Browser)"
}

OUTPUT_FILE = "results.txt"


VALID_CODES = [200, 301, 302, 403]

def onionbuster(url, wordlist, delay):
    print(Fore.CYAN + "\n[+] OnionBuster Started")
    print(Fore.YELLOW + f"[+] Target   : {url}")
    print(Fore.YELLOW + f"[+] Wordlist : {wordlist}")
    print(Fore.YELLOW + f"[+] Delay    : {delay}s (Tor Safe Mode)\n")

    try:
       with open(wordlist, "r", errors="ignore") as f, open(OUTPUT_FILE, "a") as out:
            for word in f:
                word = word.strip()
                if not word:
                    continue

                test_url = f"{url.rstrip('/')}/{word}"

                try:
                    r = requests.get(
                        test_url,
                        proxies=PROXIES,
                        headers=HEADERS,
                        timeout=40,
                        allow_redirects=False
                    )

                    if r.status_code in VALID_CODES:
                       result = f"[FOUND] {test_url} --> {r.status_code}"
                       print(Fore.GREEN + result)
                       out.write(result + "\n")

                    else:
                        print(Fore.WHITE + f"[TRY  ] {test_url} --> {r.status_code}")

                    time.sleep(delay)

                except requests.exceptions.RequestException:
                    print(Fore.RED + f"[FAIL ] {test_url}")

    except FileNotFoundError:
        print(Fore.RED + "[!] Wordlist file not found")

def main():
    parser = argparse.ArgumentParser(
        description="OnionBuster - Safe directory enumeration tool for .onion services"
    )
    parser.add_argument("-u", "--url", required=True, help="Target .onion URL")
    parser.add_argument("-w", "--wordlist", required=True, help="Wordlist file")
    parser.add_argument("-d", "--delay", type=int, default=4, help="Delay between requests (default: 4s)")

    args = parser.parse_args()
    onionbuster(args.url, args.wordlist, args.delay)

if __name__ == "__main__":
    main()
