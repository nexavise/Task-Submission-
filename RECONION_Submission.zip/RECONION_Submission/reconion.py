import requests
from bs4 import BeautifulSoup
from datetime import datetime
from urllib.parse import urlparse

# =========================
# RECONION - universal tor recon tool
# =========================
BANNER = r"""
██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗██╗ ██████╗ ███╗   ██╗
██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║██║██╔═══██╗████╗  ██║
██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║██║██║   ██║██╔██╗ ██║
██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║██║██║   ██║██║╚██╗██║
██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║██║╚██████╔╝██║ ╚████║
╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝ ╚═════╝ ╚═╝  ╚═══╝

        🧅 RECONION – Tor OSINT Recon Tool
"""

# =========================
# GLOBAL SETTINGS
# =========================
HEADERS = {
    "User-Agent": "RECONION-OSINT"
}


# =========================
# TOR AUTO-DETECTION
# =========================
def detect_tor_proxy():
    """
    Auto-detect Tor SOCKS proxy
    9050 -> Linux Tor service
    9150 -> Tor Browser (Windows)
    """
    for port in [9050, 9150]:
        proxies = {
            "http": f"socks5h://127.0.0.1:{port}",
            "https": f"socks5h://127.0.0.1:{port}"
        }
        try:
            requests.get(
                "https://check.torproject.org",
                proxies=proxies,
                timeout=8
            )
            return proxies, port
        except:
            continue
    return None, None


# =========================
# URL NORMALIZATION
# =========================
def normalize_url(target):
    if target.endswith(".onion") and not target.startswith("http"):
        return "http://" + target
    if not target.startswith("http"):
        return "http://" + target
    return target


# =========================
# TARGET SCANNING
# =========================
def scan_target(target, proxies, tor_enabled):
    url = normalize_url(target)
    result = {}

    try:
        r = requests.get(
            url,
            headers=HEADERS,
            proxies=proxies if tor_enabled else None,
            timeout=25
        )

        result["Status"] = "Active"
        result["HTTP_Code"] = r.status_code
        result["Server"] = r.headers.get("Server", "Unknown")
        result["Content-Type"] = r.headers.get("Content-Type", "Unknown")

        if "text/html" in r.headers.get("Content-Type", ""):
            soup = BeautifulSoup(r.text, "html.parser")
            result["Title"] = soup.title.string.strip() if soup.title else "No Title"
        else:
            result["Title"] = "Non-HTML / API Endpoint"

    except Exception as e:
        result["Status"] = "Inactive"
        result["Error"] = str(e)

    return result


# =========================
# SUBDOMAIN ENUMERATION
# =========================
def find_subdomains(domain, proxies, tor_enabled):
    """
    Certificate Transparency based subdomain enumeration
    (clearnet only)
    """
    subdomains = set()
    url = f"https://crt.sh/?q=%25.{domain}&output=json"

    try:
        r = requests.get(
            url,
            proxies=proxies if tor_enabled else None,
            timeout=30
        )

        if r.status_code == 200:
            for entry in r.json():
                names = entry.get("name_value", "")
                for name in names.split("\n"):
                    if "*" not in name:
                        subdomains.add(name.strip())
    except:
        pass

    return subdomains


# =========================
# MAIN FUNCTION
# =========================
def main():
    print(BANNER)

    proxies, tor_port = detect_tor_proxy()
    tor_enabled = True if proxies else False

    print(f"[+] Tor Used : {tor_enabled}")
    print(f"[+] Tor Port : {tor_port if tor_enabled else 'N/A'}\n")

    try:
        with open("targets.txt", "r") as f:
            targets = f.readlines()
    except FileNotFoundError:
        print("[-] targets.txt not found")
        return

    with open("reconion_results.txt", "w", encoding="utf-8") as report, \
         open("subdomains.txt", "w", encoding="utf-8") as subs_file:

        report.write("RECONION – UNIVERSAL TOR RECON REPORT\n")
        report.write(f"Generated : {datetime.now()}\n")
        report.write(f"Tor Used  : {tor_enabled}\n")
        report.write(f"Tor Port  : {tor_port if tor_enabled else 'N/A'}\n\n")

        for t in targets:
            target = t.strip()
            if not target:
                continue

            print(f"[+] Scanning: {target}")
            data = scan_target(target, proxies, tor_enabled)

            report.write(f"Target: {target}\n")
            for k, v in data.items():
                report.write(f"{k}: {v}\n")
            report.write("-" * 60 + "\n")

            # Subdomain enumeration (clearnet only)
            if not target.endswith(".onion"):
                domain = urlparse(normalize_url(target)).netloc
                print(f"[+] Subdomain enumeration: {domain}")

                subs = find_subdomains(domain, proxies, tor_enabled)
                for s in sorted(subs):
                    subs_file.write(s + "\n")

    print("\n✅ RECONION Scan Completed")
    print("📄 reconion_results.txt")
    print("📄 subdomains.txt\n")


if __name__ == "__main__":
    main()
