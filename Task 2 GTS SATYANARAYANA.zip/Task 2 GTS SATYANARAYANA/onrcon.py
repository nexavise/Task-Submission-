#!/usr/bin/env python3
"""
OnRCon — Onion Recon Tool
Passive + Safe Active Recon over Tor
For professional security research & threat intelligence

Features:
- Tor routing & identity rotation
- Headers, latency & fingerprinting
- Cookies (safe metadata only)
- Internal & external link mapping
- Email & PGP discovery
- robots.txt & security.txt presence
- Protocol support detection
- Auto-generated recon summary
- Optional JSON display prompt
"""

import requests
import json
import re
import time
import sys
import hashlib
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from stem import Signal
from stem.control import Controller
from requests.exceptions import Timeout, ConnectionError, ProxyError

# ================= CONFIG ================= #

TOR_PROXY = "socks5h://127.0.0.1:9050"
PROXIES = {"http": TOR_PROXY, "https": TOR_PROXY}

HEADERS = {
    "User-Agent": "OnRCon/3.0 (Professional Recon)"
}

TIMEOUT = 60
RETRIES = 3
ROTATE_TOR = True
NEWNYM_WAIT = 10

# ================= TOR ================= #

def rotate_identity():
    if not ROTATE_TOR:
        return
    print("[*] Rotating Tor identity...")
    with Controller.from_port(port=9051) as c:
        c.authenticate()
        c.signal(Signal.NEWNYM)
    time.sleep(NEWNYM_WAIT)
    print("[+] New Tor identity acquired")

# ================= VALIDATION ================= #

def normalize_onion(url):
    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    host = urlparse(url).hostname
    if not host or not host.endswith(".onion"):
        raise ValueError("Not a valid .onion address")

    if len(host.replace(".onion", "")) != 56:
        raise ValueError("Invalid v3 onion address")

    return url

# ================= EXTRACTION ================= #

EMAIL_RE = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")
PGP_RE = re.compile(r"BEGIN PGP PUBLIC KEY BLOCK", re.I)

def extract_emails_and_pgp(text):
    emails = list(set(EMAIL_RE.findall(text)))
    pgp_count = len(PGP_RE.findall(text))
    return emails, pgp_count

def extract_links(soup, base_url):
    base_host = urlparse(base_url).hostname
    internal, external = set(), set()

    for a in soup.find_all("a", href=True):
        link = urljoin(base_url, a["href"])
        host = urlparse(link).hostname
        if host == base_host:
            internal.add(link)
        elif host:
            external.add(link)

    return list(internal), list(external)

def extract_cookies(response):
    cookies = []
    for c in response.cookies:
        cookies.append({
            "name": c.name,
            "secure": c.secure,
            "http_only": c.has_nonstandard_attr("HttpOnly"),
            "expires": c.expires
        })
    return cookies

# ================= SAFE ACTIVE CHECKS ================= #

def check_protocol_support(base_url, session):
    support = {"http": False, "https": False}
    host = urlparse(base_url).hostname

    for proto in support:
        try:
            session.head(f"{proto}://{host}", timeout=15)
            support[proto] = True
        except:
            pass

    return support

def fetch_optional_file(base_url, path, session):
    try:
        r = session.get(urljoin(base_url, path), timeout=15)
        return r.status_code == 200
    except:
        return False

def favicon_hash(base_url, session):
    try:
        r = session.get(urljoin(base_url, "/favicon.ico"), timeout=15)
        if r.status_code == 200 and r.content:
            return hashlib.md5(r.content).hexdigest()
    except:
        pass
    return None

# ================= SUMMARY ================= #

def generate_summary(data):
    cookie_note = "no cookies issued" if not data["cookies"] else "cookies observed"
    https_note = "supports HTTPS" if data["protocol_support"]["https"] else "does not support HTTPS"

    return (
        f"The onion service responded with HTTP {data['status_code']} "
        f"served via {data['server_headers'].get('Server', 'unknown server')}. "
        f"The service {https_note}, {cookie_note}, "
        f"and exposed {len(data['internal_links'])} internal links. "
        f"No emails or PGP keys were discovered."
    )

# ================= RECON CORE ================= #

def recon(url):
    url = normalize_onion(url)
    session = requests.Session()
    session.proxies.update(PROXIES)
    session.headers.update(HEADERS)

    print(f"[*] Recon target → {url}")

    start = time.time()
    r = session.get(url, timeout=TIMEOUT)
    latency = int((time.time() - start) * 1000)

    soup = BeautifulSoup(r.text, "html.parser")

    emails, pgp_count = extract_emails_and_pgp(r.text)
    cookies = extract_cookies(r)
    internal_links, external_links = extract_links(soup, url)

    data = {
        "target": url,
        "status_code": r.status_code,
        "response_timing_ms": latency,
        "server_headers": dict(r.headers),
        "cookies": cookies,
        "protocol_support": check_protocol_support(url, session),
        "content_fingerprint": {
            "length": len(r.content),
            "compression": r.headers.get("Content-Encoding"),
            "etag": r.headers.get("ETag")
        },
        "robots_txt": fetch_optional_file(url, "/robots.txt", session),
        "security_txt": fetch_optional_file(url, "/.well-known/security.txt", session),
        "favicon_hash": favicon_hash(url, session),
        "page_title": soup.title.string.strip() if soup.title else None,
        "internal_links": internal_links,
        "external_links": external_links,
        "emails_found": emails,
        "pgp_keys_found": pgp_count
    }

    data["summary"] = generate_summary(data)
    return data

# ================= MAIN ================= #

if __name__ == "__main__":

    if len(sys.argv) != 2:
        print("Usage: python OnRCon.py <onion_url>")
        sys.exit(1)

    rotate_identity()
    result = recon(sys.argv[1])

    outfile = f"onrcon_{int(time.time())}.json"
    with open(outfile, "w") as f:
        json.dump(result, f, indent=4)

    print(f"[✔] Recon complete → {outfile}")

    choice = input("Do you want to view the recon JSON now? (y/n): ").strip().lower()
    if choice in ("y", "yes"):
        print("\n========== RECON OUTPUT ==========\n")
        with open(outfile, "r") as f:
            print(f.read())
        print("\n========== END ==========\n")

