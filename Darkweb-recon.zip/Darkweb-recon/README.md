# Dark Web Recon Tool (Onion OSINT)

## Overview
This project is a **Dark Web reconnaissance and threat-intelligence tool** designed to safely analyze
public Tor hidden services (.onion) for potential risk indicators.

The tool routes traffic through Tor, validates onion services, crawls public pages,
detects sensitive keywords, assigns automated risk levels, and stores results for analysis.

## Features
- Tor (SOCKS5) routing verification
- Onion service availability check
- Safe crawling (no forms, no authentication)
- Keyword-based threat detection
- Automated risk scoring (LOW / MEDIUM / HIGH)
- Persistent storage using SQLite
- Analyst-friendly HTML dashboard

## Architecture
