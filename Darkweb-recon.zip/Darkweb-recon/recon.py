from bs4 import BeautifulSoup
from urllib.parse import urlparse
import re
import time
import hashlib


def extract_recon_details(response, url):
    """
    FULL passive + safe active-lite reconnaissance
    """
    start_time = time.time()
    soup = BeautifulSoup(response.text, "html.parser")
    headers = response.headers

    recon = {}

    # =========================
    # BASIC METADATA
    # =========================
    recon["url"] = url
    recon["status_code"] = response.status_code
    recon["content_length"] = len(response.text)
    recon["response_time_ms"] = int((time.time() - start_time) * 1000)

    # =========================
    # SERVER / BACKEND HEADERS
    # =========================
    recon["server"] = headers.get("Server", "Unknown")
    recon["powered_by"] = headers.get("X-Powered-By", "Unknown")
    recon["via"] = headers.get("Via", "None")

    # =========================
    # SECURITY HEADERS
    # =========================
    recon["security_headers"] = {
        "csp": "Content-Security-Policy" in headers,
        "hsts": "Strict-Transport-Security" in headers,
        "x_frame": "X-Frame-Options" in headers,
        "x_content_type": "X-Content-Type-Options" in headers,
        "referrer_policy": "Referrer-Policy" in headers
    }

    # =========================
    # PAGE STRUCTURE / AUTH SURFACE
    # =========================
    recon["title"] = soup.title.string.strip() if soup.title else "No title"
    recon["forms_count"] = len(soup.find_all("form"))
    recon["input_fields"] = len(soup.find_all("input"))
    recon["password_fields"] = len(
        soup.find_all("input", {"type": "password"})
    )

    # =========================
    # TECHNOLOGY HINTS (PASSIVE)
    # =========================
    tech = []

    generator = soup.find("meta", {"name": "generator"})
    if generator:
        tech.append(generator.get("content"))

    scripts = [s.get("src", "") for s in soup.find_all("script") if s.get("src")]

    if any("wp-" in s for s in scripts):
        tech.append("WordPress")

    if any("jquery" in s.lower() for s in scripts):
        tech.append("jQuery")

    if any("react" in s.lower() for s in scripts):
        tech.append("React")

    if any("vue" in s.lower() for s in scripts):
        tech.append("Vue")

    recon["technology_hints"] = list(set(tech))

    # =========================
    # INTERESTING PATHS
    # =========================
    paths = set()
    for link in soup.find_all("a", href=True):
        href = link.get("href").lower()
        if any(k in href for k in [
            "login", "register", "forum",
            "paste", "leak", "dump",
            "admin", "panel"
        ]):
            paths.add(href)

    recon["interesting_paths"] = list(paths)

    # =========================
    # ACTIVITY / TIME HINTS
    # =========================
    years = re.findall(r"\b(201[5-9]|202[0-9])\b", response.text)
    recon["year_mentions"] = list(set(years))

    # =========================
    # ACTIVE-LITE RECON (SAFE)
    # =========================

    # Content hash (detect changes over time)
    recon["content_hash"] = hashlib.sha256(
        response.text.encode(errors="ignore")
    ).hexdigest()

    # Page size classification
    size = len(response.text)
    if size < 50_000:
        recon["page_size"] = "SMALL"
    elif size < 500_000:
        recon["page_size"] = "MEDIUM"
    else:
        recon["page_size"] = "LARGE"

    # Header stability indicators
    recon["header_indicators"] = {
        "etag": "ETag" in headers,
        "last_modified": "Last-Modified" in headers
    }

    return recon
