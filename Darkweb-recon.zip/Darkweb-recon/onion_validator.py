import requests
from bs4 import BeautifulSoup

PROXIES = {
    "http": "socks5h://127.0.0.1:9150",
    "https": "socks5h://127.0.0.1:9150"
}

def validate_onion(url):
    try:
        r = requests.get(url, proxies=PROXIES, timeout=25)
        soup = BeautifulSoup(r.text, "html.parser")

        title = soup.title.string.strip() if soup.title else "No title"

        return {
            "url": url,
            "status": r.status_code,
            "title": title
        }

    except Exception as e:
        return {
            "url": url,
            "status": "DOWN",
            "title": None
        }
