def calculate_risk(signals):
    if not signals:
        return "LOW"

    high_confidence = [
        ("credentials", "data"),
        ("financial", "data"),
        ("access", "breach"),
        ("extortion", "data"),
        ("vulnerability", "access")
    ]

    for a, b in high_confidence:
        if a in signals and b in signals:
            return "HIGH"

    if any(k in signals for k in ["credentials", "financial", "access", "extortion"]):
        return "HIGH"

    if any(k in signals for k in ["data", "breach", "vulnerability", "files"]):
        return "MEDIUM"

    return "LOW"
