from onion_validator import validate_onion
from crawler import crawl_onion
from risk import calculate_risk
from database import init_db, insert_scan
from explain import explain_risk
from formatter import print_recon
from intent import classify_intent
from posture import calculate_posture
from priority import calculate_priority


def load_targets(filename="targets.txt"):
    with open(filename, "r") as f:
        return list(dict.fromkeys(line.strip() for line in f if line.strip()))


init_db()
onions = load_targets()

for onion in onions:
    info = validate_onion(onion)
    status = info.get("status")

    print("\n[+] Onion Info:", info)

    if status in [200, 502, "BLOCKED"]:
        pages = crawl_onion(onion)
        seen = set()

        for page in pages:
            url = page["page"]
            if url in seen:
                continue
            seen.add(url)

            recon = page.get("recon", {})
            scraped = page.get("scraped", {})
            signals = page.get("keywords", {})

            # BLOCKED PAGE
            if recon.get("status") == "BLOCKED":
                print("  └─ Page:", url)
                print("     🚫 BLOCKED (protected)")
                continue

            # ANALYSIS
            risk = calculate_risk(signals)
            reasons = explain_risk(signals)
            intent = classify_intent(signals, recon)
            posture = calculate_posture(recon)
            priority = calculate_priority(risk, posture, signals)

            # OUTPUT
            print("  └─ Page:", url)
            print("     🔥 Risk:", risk)
            print("     🎯 Intent:", intent)
            print("     🛡 Posture:", posture, "/100")
            print("     🚨 Priority:", priority, "/100")

            if reasons:
                print("     🧠 Reasons:")
                for r in reasons:
                    print("        -", r)

            # Recon (headers, server, tech)
            print_recon(recon)

            # =========================
            # 🧾 SCRAPING OUTPUT (VISIBLE)
            # =========================
            if scraped:
                print("     🧾 Scraped Data:")

                title = scraped.get("title")
                if title:
                    print("        • Title:", title)

                links = scraped.get("internal_links", [])
                if links:
                    print("        • Internal Links:")
                    for l in links[:5]:
                        print("           -", l)

                text_sample = scraped.get("text_sample", [])
                if text_sample:
                    print("        • Text Sample:")
                    for t in text_sample[:3]:
                        print("           -", t)

            # STORE RESULT
            insert_scan(
                onion,
                url,
                signals,
                risk,
                {"recon": recon, "scraped": scraped}
            )

    else:
        print("  └─ Onion is DOWN")
        insert_scan(onion, onion, [], "DOWN", {})
