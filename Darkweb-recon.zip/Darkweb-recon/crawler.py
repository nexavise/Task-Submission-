import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, urldefrag

from analyzer import analyze_content
from recon import extract_recon_details
from scraper import scrape_page


# =========================
# TOR PROXY
# =========================
PROXIES = {
    "http": "socks5h://127.0.0.1:9150",
    "https": "socks5h://127.0.0.1:9150"
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:115.0) "
        "Gecko/20100101 Firefox/115.0"
    ),
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "close"
}


def normalize_url(url):
    """Remove fragments and normalize trailing slash"""
    url, _ = urldefrag(url)
    return url.rstrip("/")


def crawl_onion(onion_url):
    """
    Shallow crawler:
    - Crawls root page
    - Extracts visible same-onion links (1 level)
    - Does NOT deep crawl
    """

    results = []
    visited = set()

    onion_url = normalize_url(onion_url)
    base_domain = urlparse(onion_url).netloc

    session = requests.Session()
    session.proxies.update(PROXIES)
    session.headers.update(HEADERS)

    try:
        # =========================
        # ROOT REQUEST
        # =========================
        r = session.get(onion_url, timeout=(30, 120), allow_redirects=True)
        status = r.status_code

        # =========================
        # BLOCKED DETECTION
        # =========================
        if status in (401, 403, 429):
            return [{
                "page": onion_url,
                "keywords": {},
                "recon": {
                    "status": "BLOCKED",
                    "status_code": status,
                    "note": "Anti-bot / auth protection detected"
                },
                "scraped": {}
            }]

        soup = BeautifulSoup(r.text, "html.parser")

        # =========================
        # ROOT ANALYSIS
        # =========================
        visited.add(onion_url)

        results.append({
            "page": onion_url,
            "keywords": analyze_content(r.text),
            "recon": extract_recon_details(r, onion_url),
            "scraped": scrape_page(r.text, onion_url)
        })

        # =========================
        # DISCOVER INTERNAL LINKS (1 LEVEL)
        # =========================
        for a in soup.find_all("a", href=True):
            full = normalize_url(urljoin(onion_url, a["href"]))
            parsed = urlparse(full)

            if parsed.netloc != base_domain:
                continue

            if full in visited:
                continue

            # limit to shallow paths only
            if parsed.path.count("/") > 1:
                continue

            visited.add(full)

            results.append({
                "page": full,
                "keywords": {},
                "recon": {
                    "note": "Discovered from homepage (not deeply crawled)"
                },
                "scraped": {}
            })

        return results

    except requests.exceptions.Timeout:
        return [{
            "page": onion_url,
            "keywords": {},
            "recon": {
                "status": "TIMEOUT",
                "note": "Request timed out via Tor"
            },
            "scraped": {}
        }]

    except requests.exceptions.RequestException as e:
        return [{
            "page": onion_url,
            "keywords": {},
            "recon": {
                "status": "ERROR",
                "note": str(e)
            },
            "scraped": {}
        }]
