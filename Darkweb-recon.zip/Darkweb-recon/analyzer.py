FALSE_POSITIVE_PHRASES = {
    "forgot password",
    "reset password",
    "change password",
    "password manager",
    "secure login",
    "privacy policy"
}

KEYWORDS = {
    "credentials": {
        "password", "passwd", "pwd", "login", "signin",
        "username", "user:pass", "email:pass",
        "credentials", "creds", "accounts", "combo", "combolist"
    },

    "financial": {
        "credit card", "debit card", "cc", "cvv", "cvc",
        "card dump", "fullz", "bins",
        "paypal", "stripe", "cashapp", "venmo",
        "bank login", "iban", "swift"
    },

    "data": {
        "database leak", "db leak", "sql dump",
        "user database", "customer data",
        "records leaked", "data breach",
        "exposed data", "private data"
    },

    "breach": {
        "breach", "breached", "hacked",
        "compromised", "exposed", "leaked",
        "unauthorized access"
    },

    "vulnerability": {
        "zero-day", "0day", "exploit",
        "rce", "lfi", "rfi", "sqli", "xss",
        "auth bypass", "privilege escalation",
        "cve-", "poc", "proof of concept"
    },

    "access": {
        "initial access", "admin access",
        "rdp access", "vpn access",
        "ssh access", "shell access",
        "root access", "panel access"
    },

    "extortion": {
        "ransom", "ransomware", "extortion",
        "pay or leak", "leak site",
        "data will be published",
        "countdown", "deadline"
    },

    "files": {
        "sql", "csv", "json", "txt",
        "log", "backup", "archive",
        "zip", "rar", "dump file"
    }
}


def analyze_content(text):
    text = text.lower()

    # Cancel known false positives
    for phrase in FALSE_POSITIVE_PHRASES:
        if phrase in text:
            return {}

    signals = {}

    for category, words in KEYWORDS.items():
        matches = [w for w in words if w in text]
        if matches:
            signals[category] = matches

    return signals
