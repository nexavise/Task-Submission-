from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse


def scrape_page(html, base_url):
    soup = BeautifulSoup(html, "html.parser")

    data = {}

    data["title"] = soup.title.string.strip() if soup.title else None

    texts = [
        t.strip()
        for t in soup.stripped_strings
        if len(t.strip()) > 40
    ]
    data["text_sample"] = texts[:6]

    domain = urlparse(base_url).netloc
    links = set()

    for a in soup.find_all("a", href=True):
        full = urljoin(base_url, a["href"])
        if urlparse(full).netloc == domain:
            links.add(full)

    data["internal_links"] = list(links)

    return data
