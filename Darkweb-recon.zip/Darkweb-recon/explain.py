def explain_risk(signals):
    reasons = []

    for category, items in signals.items():
        reasons.append(f"{category}: {', '.join(items)}")

    return reasons
