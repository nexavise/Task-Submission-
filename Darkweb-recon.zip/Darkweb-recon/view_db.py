import sqlite3
import ast
from pprint import pprint

conn = sqlite3.connect("darkweb_recon.db")
cursor = conn.cursor()

rows = cursor.execute("""
    SELECT onion_url, page_url, keywords, risk, recon, scanned_at
    FROM scans
""")

for onion, page, keywords, risk, recon, time in rows:
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("🧅 Onion :", onion)
    print("📄 Page  :", page)
    print("🔥 Risk  :", risk)
    print("🕒 Time  :", time)

    if keywords:
        print("🔎 Signals:")
        pprint(ast.literal_eval(keywords))

    if recon:
        print("🧠 Recon:")
        pprint(ast.literal_eval(recon))

conn.close()
