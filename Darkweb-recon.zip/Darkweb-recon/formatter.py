def print_recon(recon):
    print("     🖥 Server        :", recon.get("server"))
    print("     ⚙ Powered By    :", recon.get("powered_by"))
    print("     📦 Page Size     :", recon.get("page_size"))
    print("     ⏱ Response Time :", recon.get("response_time_ms"), "ms")

    sec = recon.get("security_headers", {})
    print(
        "     🔐 Security      : "
        f"CSP {'✅' if sec.get('csp') else '❌'} | "
        f"HSTS {'✅' if sec.get('hsts') else '❌'} | "
        f"X-Frame {'✅' if sec.get('x_frame') else '❌'}"
    )

    tech = recon.get("technology_hints", [])
    if tech:
        print("     🧩 Technology    :", ", ".join(tech))

    paths = recon.get("interesting_paths", [])
    if paths:
        print("     🛣 Paths         :", ", ".join(paths))
