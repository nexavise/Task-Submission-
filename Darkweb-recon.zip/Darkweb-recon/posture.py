def calculate_posture(recon):
    score = 100

    sec = recon.get("security_headers", {})

    if not sec.get("csp"):
        score -= 20
    if not sec.get("hsts"):
        score -= 20
    if not sec.get("x_frame"):
        score -= 15
    if not sec.get("x_content_type"):
        score -= 10

    if recon.get("password_fields", 0) > 0:
        score -= 10

    if recon.get("server") == "Unknown":
        score -= 10

    return max(score, 0)
