def calculate_priority(risk, posture, signals):
    base = 0

    if risk == "HIGH":
        base += 60
    elif risk == "MEDIUM":
        base += 40
    else:
        base += 20

    if posture < 50:
        base += 20

    if "vulnerability" in signals:
        base += 15

    if "files" in signals:
        base += 10

    return min(base, 100)
