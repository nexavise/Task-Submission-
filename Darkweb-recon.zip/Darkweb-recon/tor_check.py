import requests

proxies = {
    "http": "socks5h://127.0.0.1:9150",
    "https": "socks5h://127.0.0.1:9150"
}

try:
    r = requests.get(
        "http://check.torproject.org",
        proxies=proxies,
        timeout=20
    )

    if "Congratulations" in r.text:
        print("[+] Tor is working correctly")
    else:
        print("[-] Tor connection failed")

except Exception as e:
    print("Error:", e)
