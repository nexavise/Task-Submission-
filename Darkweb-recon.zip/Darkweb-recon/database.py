import sqlite3
from datetime import datetime

DB_NAME = "darkweb_recon.db"


def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            onion_url TEXT,
            page_url TEXT,
            keywords TEXT,
            risk TEXT,
            recon TEXT,
            scanned_at TEXT
        )
    """)

    conn.commit()
    conn.close()


def insert_scan(onion, page, keywords, risk, recon):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO scans (onion_url, page_url, keywords, risk, recon, scanned_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        onion,
        page,
        str(keywords),
        risk,
        str(recon),
        datetime.utcnow().isoformat()
    ))

    conn.commit()
    conn.close()
