import csv

def save_csv(results, filename="darkweb_report.csv"):
    with open(filename, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Onion URL", "Page", "Keywords", "Risk Level"])

        for item in results:
            writer.writerow([
                item["onion"],
                item["page"],
                ", ".join(item["keywords"]),
                item["risk"]
            ])
