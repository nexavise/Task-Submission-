def classify_intent(signals, recon):
    paths = recon.get("interesting_paths", [])
    tech = recon.get("technology_hints", [])
    forms = recon.get("forms_count", 0)

    if any(p for p in paths if "forum" in p):
        return "FORUM"

    if "leak" in str(signals) or "dump" in str(signals):
        return "LEAK / DUMP"

    if any(x in str(signals) for x in ["selling", "price", "btc"]):
        return "MARKETPLACE"

    if forms == 0 and "archive" in recon.get("title", "").lower():
        return "RESEARCH / ARCHIVE"

    if forms == 0:
        return "INFORMATIONAL"

    return "UNKNOWN"
