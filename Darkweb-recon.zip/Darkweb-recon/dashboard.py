import sqlite3

DB_NAME = "darkweb_recon.db"
HTML_FILE = "dashboard.html"

def generate_dashboard():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT onion_url, page_url, keywords, risk, scanned_at
        FROM scans
        ORDER BY scanned_at DESC
    """)

    rows = cursor.fetchall()
    conn.close()

    html = """
    <html>
    <head>
        <title>Dark Web Recon Dashboard</title>
        <style>
            body { font-family: Arial; background:#111; color:#eee; }
            table { width:100%; border-collapse: collapse; }
            th, td { padding:10px; border-bottom:1px solid #333; }
            th { background:#222; }
            .HIGH { color:#ff4d4d; font-weight:bold; }
            .MEDIUM { color:#ffaa00; font-weight:bold; }
            .LOW { color:#4dff4d; }
        </style>
    </head>
    <body>
        <h2>🕵️ Dark Web Recon Dashboard</h2>
        <table>
            <tr>
                <th>Onion</th>
                <th>Page</th>
                <th>Keywords</th>
                <th>Risk</th>
                <th>Scanned At (UTC)</th>
            </tr>
    """

    for row in rows:
        onion, page, keywords, risk, time = row
        html += f"""
        <tr>
            <td>{onion}</td>
            <td>{page}</td>
            <td>{keywords}</td>
            <td class="{risk}">{risk}</td>
            <td>{time}</td>
        </tr>
        """

    html += """
        </table>
    </body>
    </html>
    """

    with open(HTML_FILE, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[+] Dashboard generated: {HTML_FILE}")

if __name__ == "__main__":
    generate_dashboard()
